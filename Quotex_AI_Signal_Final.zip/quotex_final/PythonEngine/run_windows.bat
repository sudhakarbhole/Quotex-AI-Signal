@echo off
python -m pip install -r requirements.txt
python -m streamlit run trading_signal_bot.py
pause
